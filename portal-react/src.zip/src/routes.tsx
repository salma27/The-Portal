import Home from "./components/Home";

export const routes = [
    {id: 1, path: '/home', element: <Home/>},

];