import './interfaces';

export const options: Option[] = [
    { id: "spare-parts", label: "Spare Parts", href: "#spare-parts" },
    { id: "maintenance", label: "Maintenance", href: "#maintenance" },
    { id: "products", label: "Products", href: "#products" },
    { id: "retrofit", label: "Retrofit", href: "#retrofit" },
    { id: "our-purpose", label: "OUR PURPOSE", href: "#our-purpose" },
  ];

