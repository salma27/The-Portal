interface Option {
  label: string;
  id: string;
  href: string;
}

interface ElementRoute {
  path: string;
  id: number;
  element: any;
}