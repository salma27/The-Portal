const Home: React.FC = ({}) => {
return <>
Home
</>
}
export default Home;